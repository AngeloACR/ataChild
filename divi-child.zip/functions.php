<?php

function my_theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles', 11 );


function loginRedirect( $url, $request, $user ){
	if( $user && is_object( $user ) && is_a( $user, 'WP_User' ) ) {
		if( $user->has_cap( 'administrator') or $user->has_cap( 'author')) {
			$url = admin_url();
		} else {
			$url = home_url('/index.php/course');
		}
	}
return $url;
}

add_filter('login_redirect', 'loginRedirect', 10, 3 );

add_action('wp_logout','logoutRedirect');
function logoutRedirect(){
	wp_redirect( home_url() );
	exit();
}

include_once('atashorts.php');
